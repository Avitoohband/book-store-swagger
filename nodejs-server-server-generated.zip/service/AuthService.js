'use strict';


/**
 * Get a token
 * Return a token for open access.
 *
 * returns inline_response_200
 **/
exports.getToken = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "token" : "token"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

