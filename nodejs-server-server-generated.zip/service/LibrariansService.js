'use strict';


/**
 * Adds a book
 * Adds a book to the library
 *
 * body Book Book item to add (optional)
 * no response value expected for this operation
 **/
exports.addBook = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

